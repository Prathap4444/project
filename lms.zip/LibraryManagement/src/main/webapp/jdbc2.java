import java.sql.*;
class jdbc2
{
  public static void main(String args[])
  {
    try
    {
//      Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");

       Class.forName("com.mysql.jdbc.Driver");
//      Connection con = DriverManager.getConnection("JDBC:ODBC:DON","","");
Connection con=DriverManager.getConnection(  
"jdbc:mysql://localhost:3306/lib","root","mysql");  

      Statement stmt = con.createStatement();

      stmt.executeUpdate("insert into memberlogin values('101','ravi','ravi','ravi')");
      System.out.println("One row inserted");
      stmt.close();
      con.close();
    }
    catch(Exception e)
    {
      System.out.println("Exception occured " + e);
    }
  }
}

          
          
