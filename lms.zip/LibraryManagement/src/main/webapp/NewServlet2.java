/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author htg
 */
@WebServlet(urlPatterns = {"/NewServlet2"})
public class NewServlet2 extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet NewServlet2</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet NewServlet2 at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }
    <%@page import ="java.sql.*"%>  <%@ page import ="java.io.*,java.sql.*,java.util.*,dbcon.dbconnection"%>
    <%
       

    try
    {
           // Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
           // Connection con = DriverManager.getConnection("JDBC:ODBC:geo","","");
    		
    		     Connection con=dbconnection.getConnection();  
    		//out.println("test0");
    			String t1=request.getParameter("textfield").trim();
    					//out.println("test1");
    			String t2=request.getParameter("bookname").trim();
    					//out.println("test2");
    			String t3=request.getParameter("publisher").trim();
    					//out.println("test3");
    			String t4=request.getParameter("dofpu").trim();
    					//out.println("test4");
    			String t5=request.getParameter("author").trim();
    					//out.println("test5");
    			String t6=request.getParameter("category").trim();
    					//out.println("test6");
    			String t7=request.getParameter("nooffco").trim();
    					//out.println("test7");
    			String t8=request.getParameter("price").trim();
    					//out.println("test8");
    			String t9=request.getParameter("dofpur").trim();
    					//out.println("test9");
            Statement stmt=con.createStatement();
    		//out.println("test00");
             ResultSet rs;
             String s5="",s2="";
    		 
    		  Cookie cookies1[]=request.getCookies();
          Cookie cookie1;
          for(int i=0;i<cookies1.length;i++)
          {
              cookie1=cookies1[i];
              if(cookie1.getName().equals("i"))
                  s2=cookies1[i].getValue();
                    
          }
    		 
            /* int found=0;
              rs=stmt.executeQuery("select * from citizen");
            
            
            while(rs.next())
            {
                 s5=rs.getString("username").trim();
               // s6=rs.getString("password").trim();
               //s1=rs.getString("category").trim();
              if(t8.equals(s5))
              {
                       found=1;
                        break;
              }   
             }
            rs.close();
            
            if(found==0)
            {
            */
            		//out.println("test1");
            PreparedStatement pstmt=con.prepareStatement("insert into bookadd values(?,?,?,?,?,?,?,?,?)");   
    		  pstmt.setString(1,t1);
    		  pstmt.setString(2,t2);
    		  pstmt.setString(3,t3);
    		  pstmt.setString(4,t4);
    		  pstmt.setString(5,t5);
    		  pstmt.setString(6,t6);
    		  pstmt.setString(7,t7);
    		  pstmt.setString(8,t8);
    		  pstmt.setString(9,t9);
    		  
               		//out.println("test2");
                
                              
                pstmt.executeUpdate(); 
                
               
                
                pstmt.close();  
                		//out.println("test3");
               
    		   response.sendRedirect("bookaddsucc.jsp");
    		   
                con.close(); 
            /*  }
          else
                response.sendRedirect("homepage.html"); */
    			
    			//out.println("submitted successfully");
    }
        catch(Exception e)
        {
          out.println("Exception occured" +e);
        }
    %>
    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
