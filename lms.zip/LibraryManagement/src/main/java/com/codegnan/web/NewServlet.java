package com.codegnan.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.math.BigInteger;
import java.security.SecureRandom;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class NewServlet
 */
public class NewServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public NewServlet() {
        super();
        // TODO Auto-generated constructor stub
    }
    
    private static final int MAXIMUM_BIT_LENGTH = 25;
   	private static final int RADIX = 32;
       /**
        * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
        * methods.
        *
        * @param request servlet request
        * @param response servlet response
        * @throws ServletException if a servlet-specific error occurs
        * @throws IOException if an I/O error occurs
        */
           public static String getRandomText() {
   		// cryptographically strong random number generator
   		SecureRandom random = new SecureRandom();

   		// randomly generated BigInteger
   		BigInteger bigInteger = new BigInteger(MAXIMUM_BIT_LENGTH, random);

   		// String representation of this BigInteger in the given radix.
   		String randomText = bigInteger.toString(RADIX);
   		
   		return randomText;
   	}

           
       protected void processRequest(HttpServletRequest request, HttpServletResponse response)
               throws ServletException, IOException {
           response.setContentType("text/html;charset=UTF-8");
           try (PrintWriter out = response.getWriter()) 
           {
              
               String randomText = getRandomText();
   		
   	 out.println("Generated random alpha numeric text : " + randomText);
            String u="asdf"   ;
            Cookie cook1=new Cookie("captcha",randomText);
                   cook1.setMaxAge(1200);
                   response.addCookie(cook1); 
            
           }
       }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		processRequest(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		processRequest(request, response);
	}

}
